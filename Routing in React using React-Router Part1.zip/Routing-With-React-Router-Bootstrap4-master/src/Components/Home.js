import React from 'react';

const Home = () => (
  <div>
    <h1>This Is From Dashboard Page</h1>
  </div>
)

export default Home;
