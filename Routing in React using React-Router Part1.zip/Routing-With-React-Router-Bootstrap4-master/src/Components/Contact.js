import React from 'react';

const Contact = () => (
  <div>
    <h1>This Is From Contact Us Page</h1>
  </div>
)

export default Contact;
