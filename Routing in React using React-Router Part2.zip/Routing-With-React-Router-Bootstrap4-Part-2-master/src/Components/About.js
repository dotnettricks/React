import React from 'react';

const About = () => (
  <div>
    <h1>This Is From About Us Page</h1>
  </div>
)

export default About;
